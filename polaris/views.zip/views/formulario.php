<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-1 main">        
<div class="page-header">
<h3>Seleccione una opción de búsqueda</h3>

</div>
<div class="controls">				
<a id="vin" class="btn btn-primary"><span class="glyphicon glyphicon-barcode"></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;VIN&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>								
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a id="cliente" class="btn btn-info"><span class="glyphicon glyphicon-user"></span>&nbsp;&nbsp;&nbsp;Cliente&nbsp;&nbsp;&nbsp;</a>
</div>
<div style="display: block;" id="ajax" class="ajax">
</div>
</div>