<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
<div class="panel panel-default">
<div class="panel-heading">
    <h3 class="panel-title centrar">Polaris <?php print $vin ?></h3>    
  </div>
  <div class="well">
    
  </div>
  </div>
  </div>